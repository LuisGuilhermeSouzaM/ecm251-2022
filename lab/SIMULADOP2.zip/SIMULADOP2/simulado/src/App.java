public class App {
    public static void main(String[] args) throws Exception {
        V1 a = new V2();
        System.out.printf("%.1f\n", a.mv2(2));
    }
}
